<!-- Navigation Bar -->
<div class="left_panel sticky-top container text-center pt-3">
    <img class="mt-3" src="../images/company-logo.png" alt="Varcons Logo" style ="width: 200px;">
    <p class="company_name mt-2 mb-0">Varcons Technologies Private Limited</p>
    <p class="system_name">Daily Attendance Tracker System</p>

    <!-- Links / buttons -->
    <nav class="nav flex-column nav-pills mt-4 p-2 gap-2">
        <a class="nav_button nav-link" href="login-report.php">Log in Report</a>
        <a class="nav_button nav-link" href="employee-maintenance.php">Employee Maintenance</a>
        <a class="nav_button nav-link" href="daily-report.php">Daily Report</a>
        <a class="nav_button nav-link" href="monthly-report.php">Monthly Report</a>
        <span class="log_out_button mb-3"><a class="nav_button nav-link" href="admin-login.php">Log out</a></span>
    </nav>
</div>