<?php
    // Include your database connection file
    include_once __DIR__ . '/../php/connection.php';

    // Enable MySQLi error reporting for debugging
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

    // Validate the 'emp_id' GET parameter
    if (isset($_GET['emp_id']) && is_numeric($_GET['emp_id'])) {
        $emp_id = (int)$_GET['emp_id'];

        // Prepare SQL DELETE statement
        $sql = "DELETE FROM employee WHERE emp_id = ?";

        // Prepare the statement
        if ($stmt = $conn->prepare($sql)) {
            // Bind parameters
            $stmt->bind_param("i", $emp_id);

            // Execute and check if a row was actually deleted
            if ($stmt->execute()) {
                if ($stmt->affected_rows > 0) {
                    // Success: redirect
                    header("Location: employee-maintenance.php");
                    exit();
                } else {
                    echo "No employee found with the given ID.";
                }
            } else {
                // Execution failed
                echo "Execute failed: (" . $stmt->errno . ") " . $stmt->error;
            }

            // Close statement
            $stmt->close();
        } else {
            echo "Failed to prepare the SQL statement.";
        }
    } else {
        echo "Invalid or missing employee ID.";
    }

    // Close database connection
    $conn->close();
?>